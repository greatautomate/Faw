const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function checkssh(serverId) {
  console.log(`Checking SSH account on server ${serverId}`);

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/checkssh?auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const sshData = response.data.data;
            let msg = `
🌟 *CHECK SSH ACCOUNT* 🌟
`;
            sshData.forEach(user => {
              msg += `
┌─────────────────────────────
│ Username: \`${user.user}\`
│ IP Limit: \`${user.ip_limit}\`
│ IP Count: \`${user.total_ip_connect}\`
└─────────────────────────────
`;
            });
            msg += `✨ Thank you for using our service! ✨`;
            console.log('SSH account checked successfully');
            return resolve(msg);
          } else {
            console.log('Error checking SSH account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while checking SSH:', error);
          return resolve('❌ An error occurred while checking SSH. Please try again later.');
        });
    });
  });
}

module.exports = { checkssh };