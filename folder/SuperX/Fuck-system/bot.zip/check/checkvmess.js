const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function checkvmess(serverId) {
  console.log(`Checking VMess account on server ${serverId}`);

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/checkvmess?auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const vmessData = response.data.data;
            let msg = `
🌟 *CHECK VMESS ACCOUNT* 🌟
`;
            vmessData.forEach(user => {
              msg += `
┌─────────────────────────────
│ Username: \`${user.user}\`
│ Usage: \`${user.usage}\`
│ Quota: \`${user.quota}\`
│ IP Limit: \`${user.ip_limit}\`
│ IP Count: \`${user.ip_count}\`
│ Log Count: \`${user.log_count}\`
└─────────────────────────────
`;
            });
            msg += `✨ Thank you for using our service! ✨`;
            console.log('VMess account checked successfully');
            return resolve(msg);
          } else {
            console.log('Error checking VMess account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while checking VMess:', error);
          return resolve('❌ An error occurred while checking VMess. Please try again later.');
        });
    });
  });
}

module.exports = { checkvmess };