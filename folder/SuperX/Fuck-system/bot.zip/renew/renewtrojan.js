const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function renewtrojan(username, exp, quota, limitip, serverId) {
  console.log(`Renewing Trojan account for ${username} with expiry ${exp} days, quota ${quota} GB, limit IP ${limitip} on server ${serverId}`);
  
  // Validate username
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) {
    return '❌ Invalid username. Please use only letters and numbers without spaces.';
  }

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/renewtrojan?user=${username}&exp=${exp}"a=${quota}&iplimit=${limitip}&auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const trojanData = response.data.data;
            const msg = `
🌟 *RENEW TROJAN PREMIUM* 🌟

🔹 *Account Information*
┌─────────────────────────────
│ Username: \`${username}\`
│ Expiry: \`${trojanData.exp}\`
│ Quota: \`${trojanData.quota}\`
│ IP Limit: \`${trojanData.limitip} IP\`
└─────────────────────────────
✅ Account ${username} successfully renewed
✨ Enjoy using our service! ✨
`;
            console.log('Trojan account renewed successfully');
            return resolve(msg);
          } else {
            console.log('Error renewing Trojan account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while renewing Trojan:', error);
          return resolve('❌ An error occurred while renewing Trojan. Please try again later.');
        });
    });
  });
}

module.exports = { renewtrojan };